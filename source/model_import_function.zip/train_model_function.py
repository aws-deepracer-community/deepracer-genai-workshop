# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

import json
import logging

import boto3
import cfnresponse
import deepracer
from botocore.exceptions import ClientError

s3_client = boto3.client("s3")


def lambda_handler(event, context):
    print(json.dumps(event))
    try:
        if event["RequestType"] == "Create":
            handle_create(event, context)
        elif event["RequestType"] == "Update":
            handle_update(event, context)
        elif event["RequestType"] == "Delete":
            handle_delete(event, context)
    except ClientError as exception:
        logging.error(exception)
        cfnresponse.send(event, context, cfnresponse.FAILED, {}, error=str(exception))


def handle_create(event, context):
    """Start a training job for a DeepRacer model"""
    my_session = boto3.session.Session()
    my_region = my_session.region_name
    print("**Current region identified: " + my_region)
    print("**Creating a training job for a  DeepRacer model")

    model_name = event["ResourceProperties"]["ModelName"]
    description = event["ResourceProperties"]["Description"]
    max_training_time = event["ResourceProperties"]["MaxTrainingTime"]
    track_arn = event["ResourceProperties"]["TrackArn"]
    direction = event["ResourceProperties"]["Direction"]

    hyper_parameters = {
        "batch_size": "32",
        "num_epochs": "3",
        "stack_size": "1",
        "lr": "0.001",
        "exploration_type": "Categorical",
        "beta_entropy": "0.5",
        "e_greedy_value": "1",
        "epsilon_steps": "10000",
        "discount_factor": "0.95",
        "loss_type": "Huber",
        "num_episodes_between_training": "5",
    }

    response_data = deepracer.create_model(
        model_name,
        description,
        max_training_time,
        hyper_parameters,
        track_arn,
        direction,
    )
    print(response_data)

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {"ModelArn": response_data["ModelArn"]},
        physicalResourceId=response_data["ModelArn"],
    )


def handle_delete(event, context):
    """Delete the imported file in DeepRacer"""
    model_arn = event["PhysicalResourceId"]
    print("Received delete event, model_arn={}".format(model_arn))
    try:
        response = deepracer.delete_model(model_arn)
        print(f"Delete model response: {response}")

    except Exception as e:
        print(f"Error deleting DeepRacer model: {e}")

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {},
        physicalResourceId=event["PhysicalResourceId"],
    )


def handle_update(event, context):
    """There is nothing to update on an imported DeepRacer model, so just pass through"""
    model_arn = event["PhysicalResourceId"]
    logging.info("Received Update event, model_arn={}".forma(model_arn))

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {"ModelArn": model_arn},
        physicalResourceId=event["PhysicalResourceId"],
    )
