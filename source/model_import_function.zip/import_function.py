# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

import json
import logging
import os
import shutil
import tarfile

import boto3
import cfnresponse
import deepracer
from botocore.exceptions import ClientError

s3_client = boto3.client("s3")


def lambda_handler(event, context):
    print(json.dumps(event))
    try:
        if event["RequestType"] == "Create":
            handle_create(event, context)
        elif event["RequestType"] == "Update":
            handle_update(event, context)
        elif event["RequestType"] == "Delete":
            handle_delete(event, context)
    except ClientError as exception:
        logging.error(exception)
        cfnresponse.send(event, context, cfnresponse.FAILED, {}, error=str(exception))


def handle_create(event, context):
    """
    Invoked when the Cloudformation resource is created.
    Download a compressed deepracer model, decompress it, upload to S3 and then finally start an import job
    """
    my_session = boto3.session.Session()
    my_region = my_session.region_name
    print("**Current region identified: " + my_region)

    print("**Importing DeepRacer model")
    source_bucket = event["ResourceProperties"]["SourceS3Bucket"]
    source_key = event["ResourceProperties"]["SourceS3Key"]
    target_bucket = event["ResourceProperties"]["TargetS3Bucket"]
    model_name = event["ResourceProperties"]["ModelName"]
    import_role_arn = event["ResourceProperties"]["ImportRoleArn"]

    local_file_path = f"/tmp/{model_name}.tgz"
    extracted_path = f"/tmp/{model_name}"

    # Download the zipped DeepRacer Model
    try:
        download_file(
            source_bucket,
            source_key,
            local_file_path,
        )

        # Decompress the file
        decompress_tar_file(local_file_path, extracted_path)

        # Upload the decompressed model directory to an S3 bucket
        upload_directory_to_s3(extracted_path, target_bucket)  # , s3_path=model_name)

        # Delete downloaded file from /tmp
        delete_local_file(local_file_path)
        delete_local_directory(extracted_path)

        # Import model to DeepRacer
        s3_model_path = f"s3://{target_bucket}/{model_name}"
        model_arn = deepracer.import_model(model_name, s3_model_path, import_role_arn)

        # Delete the downloaded model file
        delete_s3_prefix(target_bucket, model_name)

        if "EvaluationJob" in event["ResourceProperties"]:
            print("Starting evaluation job...")
            evaluation_job = event["ResourceProperties"]["EvaluationJob"]
            track_arn = evaluation_job["TrackArn"]
            evaluation_name = evaluation_job["EvaluationName"]
            direction = evaluation_job["Direction"]

            # TODO manage errors if quota limit is reached....
            deepracer.start_evaluation_job(
                model_arn, track_arn, direction, evaluation_name
            )
        else:
            print("No evaluation job defined")

    except Exception as e:
        print(f"Error importing DeepRacer model: {e}")

        if model_arn is None:
            model_arn = f"NoModelArn:{model_name}"

        cfnresponse.send(
            event,
            context,
            cfnresponse.FAILED,
            {"ModelArn": model_arn},
            physicalResourceId=model_arn,
        )
        return

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {"ModelArn": model_arn},
        physicalResourceId=model_arn,
    )


def handle_delete(event, context):
    """Delete the imported file in DeepRacer"""
    target_bucket = event["ResourceProperties"]["TargetS3Bucket"]
    model_name = event["ResourceProperties"]["ModelName"]
    model_arn = event["PhysicalResourceId"]
    print("Received delete event, model_arn={}".format(model_arn))
    try:
        response = deepracer.delete_model(model_arn)
        print(f"Delete model response: {response}")

        # clean up model files in S3
        delete_s3_prefix(target_bucket, model_name)

    except Exception as e:
        print(f"Error deleting DeepRacer model: {e}")

        # TODO add error handling
        # cfnresponse.send(
        #     event,
        #     context,
        #     cfnresponse.FAILED,
        #     {},
        #     physicalResourceId=event["PhysicalResourceId"],
        # )
        # return

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {},
        physicalResourceId=event["PhysicalResourceId"],
    )


def handle_update(event, context):
    """There is nothing to update on an imported DeepRacer model, so just pass through"""
    model_arn = event["PhysicalResourceId"]
    logging.info("Received Update event, model_arn={}".format(model_arn))

    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        {"ModelArn": model_arn},
        physicalResourceId=event["PhysicalResourceId"],
    )


def delete_local_file(local_file_path):
    """Delete file from /tmp"""
    if os.path.exists(local_file_path):
        print(f"Deleting file: {local_file_path}")
        os.remove(local_file_path)


def delete_local_directory(local_dir_path):
    """Delete folder from /tmp"""
    if os.path.exists(local_dir_path):
        print(f"Deleting folder: {local_dir_path}")
        shutil.rmtree(local_dir_path)


# create function to download file from s3
def download_file(bucket, key, local_file_path):
    """
    Downloads a file from S3 to the local file system.

    Args:
        bucket (string): The S3 bucket name.
        key (string): The S3 key of the file to download.
        local_file_path (string): The local file path to store the file.

    Returns:
        None.
    """
    print(f"Downloading file from {bucket}, {key} and storing it in {local_file_path}")
    s3_client.download_file(bucket, key, local_file_path)
    print("File downloaded successfully.")


def decompress_tar_file(path_to_file_to_extract, extraction_path):
    """
    Decompresses a tar file and stores the decompressed files in the specified extraction path.

    Args:
        path_to_file_to_extract (string): The path to the tar file to decompress.
        extraction_path (string): The path to store the decompressed files.

    Returns:
        None.
    """
    try:
        print(
            f"Decompressing file {path_to_file_to_extract} and storing it in {extraction_path}"
        )
        with tarfile.open(path_to_file_to_extract, "r:gz") as tar:
            os.makedirs(extraction_path, exist_ok=True)
            tar.extractall(path=extraction_path)
        print("File uncompressed successfully.")
    except Exception as e:
        print(f"An error occurred while extracting the file: {e}")


# Function to upload a directory to S3
def upload_directory_to_s3(local_path, target_bucket, s3_path=""):
    """
    Uploads a directory to S3.

    Args:
        local_path (string): The path to the local directory to upload.
        target_bucket (string): The S3 bucket name to upload to.
        s3_path (string, optional): The S3 path to upload the directory to. Defaults to "".

    Returns:
        None
    """
    for root, dirs, files in os.walk(local_path):
        for file in files:
            local_file_path = os.path.join(root, file)
            s3_file_path = os.path.join(
                s3_path, os.path.relpath(local_file_path, local_path)
            )
            try:
                s3_client.upload_file(local_file_path, target_bucket, s3_file_path)
                print(f"Uploaded {local_file_path} to {s3_file_path}")
            except Exception as e:
                print(f"Failed to upload {local_file_path} to {s3_file_path}: {e}")


def delete_s3_prefix(bucket, prefix):
    """
    Deletes all objects in a S3 bucket with a given prefix.

    Args:
        bucket (string): The S3 bucket name.
        prefix (string): The S3 prefix to delete.

    Returns:
        None.
    """
    try:
        print(f"Deleting all objects with prefix '{prefix}' in bucket '{bucket}'...")
        objects_to_delete = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        for obj in objects_to_delete.get("Contents", []):
            s3_client.delete_object(Bucket=bucket, Key=obj["Key"])
        print(
            f"All objects with prefix '{prefix}' in bucket '{bucket}' has been deleted."
        )
    except Exception as e:
        print(f"An error occurred: {e}")
